package com.example.demo6;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    Aluno aluno1 = new Aluno("1234", "7", pessoal1);
    Pessoal pessoal1 = new Pessoal("Ednaldo", "9999-9999", "ednaldo@hotmail.com");
    Pessoal pessoal2 = new Pessoal("paulo", "6666-6666", "paulo@senai.br");
    Endereco endereco1 = new Endereco("rua1", "floripa", "uf?", "123134", "brasil");
    Professor professor1 = new Professor("1002", pessoal2);

    System.out.println(endereco1);
    System.out.println(aluno1);
    System.out.println(professor1);

}