package com.example.demo6;

public class Aluno {

    private String matricula;
    private String media;
    private Pessoal pessoal;

    public Aluno() {
        this.matricula = matricula;
        this.media = media;
        this.pessoal = pessoal;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMedia() {
        return media;
    }

    public void setMedia(String media) {
        this.media = media;
    }

    public Pessoal getPessoal() {
        return pessoal;
    }

    public void setPessoal(Pessoal pessoal) {
        this.pessoal = pessoal;
    }

    @Override
    public String toString() {
        return "Aluno{" +
                "matricula='" + matricula + '\'' +
                ", media='" + media + '\'' +
                ", pessoal=" + pessoal +
                '}';
    }
}



