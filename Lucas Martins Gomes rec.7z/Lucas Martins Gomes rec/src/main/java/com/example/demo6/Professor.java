package com.example.demo6;

public class Professor {

    private String salario;

    public Professor(String salario, Pessoal pessoal2) {
        this.salario = salario;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        return "Professor{" +
                "salario='" + salario + '\'' +
                '}';
    }
}
